//
//  DMFlexibleSampleViewController.h
//  DomobSample
//
//  Copyright (c) 2013年 domob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DMAdView.h"

@interface DMFlexibleSampleViewController : UIViewController<DMAdViewDelegate>
{
    DMAdView *_dmFlexibleAdView;
}

@end
