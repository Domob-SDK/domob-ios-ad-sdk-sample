//
//  main.m
//  DomobSample
//
//  Created by sui_xin on 12-10-8.
//  Copyright (c) 2012年 domob. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DMAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DMAppDelegate class]));
    }
}
